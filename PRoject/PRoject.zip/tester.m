%constants
f = 1/298.256421867;
Re = 6378.13655;
H= 0.83991;
w= [0, 0, 72.9217e-6];
lat=13.0344722;
Elong=(360- 282.48905);
%Input ro and rodot for the mid point to compute r and rdot 
ro=910.3581725;
rod=2.35271186;
k=585;

%sidereal time with time base from Az, El measurements
St = LST(2016, 8, 27, IRS(:,1),Elong);%change year month and date here
%right ascension and declination for each instance of time from Az,El
%measurements
[asc, dec]= alphadelta(IRS(:,2),IRS(:,3),St(:,1),lat);
%L, Ldot measurements by polynomial fitting of the asc and dec with time
%base in second by taking origin at the mid point of measurement
[L,Ld,Ldt,yasc,ydec,yascd,ydecd,pasc,pasdot]= Lunits(IRS(:,6),asc,dec);

%calculate R of the observatory at each St instance
for i = 1:1170
    R(i,:) = [(Re/sqrt(1-(2*f - f*f)*(sind(lat))^2) + H)*cosd(lat)*cosd(St(i)),(Re/sqrt(1-(2*f - f*f)*sind(lat)^2) + H)*cosd(lat)*sind(St(i)),(Re*(1 - f)^2/sqrt(1-(2*f - f*f)*sind(lat)^2) + H)*sind(lat)];
    Rd(i,:)= cross(w,R(i,:));
end
%calculate r for the mid point
rf=(R(k,:)+ ro*L(k,:));
v=Rd(k,:)+(ro*Ldt(k,:))+(rod*L(k,:));
vp=norm(v);
rfp=norm(rf);
Rk=(R(k,:));
Rp=norm(R(k,:));
%placeholders for plotting to check accuracy
%plot(IRS(1:1170,1),asc(:,1),IRS(1:1170,1),yasc(:,1));
%plot(IRS(1:1170,1),asc,IRS(1:1170,1),yasc);

global mu
deg = pi/180;
mu = 398600;
%...Input data:
r = rf;
%...
%...Algorithm 4.1:
coe = coe_from_sv(r,v);
%...Echo the input data and output results to the command window:
fprintf('---------------------------------------------------')
fprintf('\n Example 4.3\n')
fprintf('\n Gravitational parameter (km�3/s�2) = %g\n', mu)
fprintf('\n State vector:\n')
fprintf('\n r (km) = [%g %g %g]', ...
r(1), r(2), r(3))
fprintf('\n v (km/s) = [%g %g %g]', ...
v(1), v(2), v(3))
disp(' ')
fprintf('\n Angular momentum (km�2/s) = %g', coe(1))
fprintf('\n Eccentricity = %g', coe(2))
fprintf('\n Right ascension (deg) = %g', coe(3)/deg)
fprintf('\n Inclination (deg) = %g', coe(4)/deg)
fprintf('\n Argument of perigee (deg) = %g', coe(5)/deg)
fprintf('\n True anomaly (deg) = %g', coe(6)/deg)
fprintf('\n Semimajor axis (km): = %g', coe(7))
%...if the orbit is an ellipse, output its period:
if coe(2)<1
    T = 2*pi/sqrt(mu)*coe(7)^1.5; % Equation 2.73
    fprintf('\n Period:')
    fprintf('\n Seconds = %g', T)
    fprintf('\n Minutes = %g', T/60)
    fprintf('\n Hours = %g', T/3600)
    fprintf('\n Days = %g', T/24/3600)
end
fprintf('\n-----------------------------------------------\n')
% ������������������������������������������������������������







